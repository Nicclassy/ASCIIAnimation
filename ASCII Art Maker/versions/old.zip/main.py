import pygame

from button import Button
from constants import *
from keymods import shift_key, alt_key, shift_alt_key
from boxes import ArtBox, CharacterBox, Boxes
from interfacebuttons import (
    save_button, clear_button, quit_button, load_button, SaveButton, ClearButton, LoadButton
)

pygame.init()

pygame.display.set_caption('ASCII Art Maker')
display = pygame.display.set_mode((DISPLAY_WIDTH, DISPLAY_HEIGHT), pygame.RESIZABLE)

CHARACTER_BOX_HEIGHT = 2
CHARACTER_BOX_WIDTH = 10
ART_BOX_HEIGHT = 12
ART_BOX_WIDTH = 8

boxes = Boxes([
    CharacterBox("character", 70, 70, 10, DISPLAY_HEIGHT // 5 * 4,
                 CHARACTER_BOX_HEIGHT, CHARACTER_BOX_WIDTH, CHARACTER_BOX_COLOUR),
    ArtBox("art", 70, 70, DISPLAY_HEIGHT // 4, DISPLAY_HEIGHT // 20,
           ART_BOX_HEIGHT, ART_BOX_WIDTH, ART_BOX_COLOUR),
])
character_box = boxes["character"]
art_box = boxes["art"]
running = True
while running:
    display.fill(BACKGROUND_COLOUR)
    boxes.draw_box_features(display)
    Button.draw_all_buttons(display)
    for event in pygame.event.get():
        match event.type:
            case pygame.QUIT:
                running = False
            case pygame.KEYDOWN:
                match event.key:
                    case pygame.K_LEFT:
                        character_box.move_highlight_left()
                    case pygame.K_RIGHT:
                        character_box.move_highlight_right()
                    case pygame.K_DOWN:
                        character_box.move_highlight_down()
                    case pygame.K_UP:
                        character_box.move_highlight_up()
                    case _:
                        if 0 < event.key <= 1114112:
                            mods = pygame.key.get_mods()
                            character = chr(event.key)
                            if mods & pygame.KMOD_ALT and mods & pygame.KMOD_SHIFT:
                                key = shift_alt_key(character)
                            elif mods & pygame.KMOD_ALT:
                                key = alt_key(character)
                            elif mods & pygame.KMOD_SHIFT:
                                key = shift_key(character)
                            else:
                                key = character
                            if ord(key) in PERMITTED_CHARACTER_UNICODES:
                                character_box.add_character(key)
            case pygame.MOUSEBUTTONDOWN:
                boxes.check_box_intersect(display, pygame.mouse.get_pos(), event.button)
                if save_button.clicked():
                    SaveButton.export(boxes, json_file=JSON_FILE)
                    print("Saved current data.")
                elif clear_button.clicked():
                    ClearButton.clear_data(art_box, character_box)
                    print("Reset all characters.")
                elif quit_button.clicked():
                    print("Qutting program.")
                    quit()
                elif load_button.clicked():
                    if (loaded_file := LoadButton.load_last_file(boxes)) is not None:
                        print(f"Loaded data from the file named {loaded_file!r}.")
                    else:
                        print("No existing file to load.")
            case pygame.WINDOWRESIZED:
                DISPLAY_HEIGHT = display.get_height()
                DISPLAY_WIDTH = display.get_width()
                print("yes, this is happening", DISPLAY_HEIGHT, DISPLAY_WIDTH)
                boxes = Boxes([
                    CharacterBox("character", 70, 70, 10, DISPLAY_HEIGHT // 5 * 4,
                                 CHARACTER_BOX_HEIGHT, CHARACTER_BOX_WIDTH, CHARACTER_BOX_COLOUR),
                    ArtBox("art", 70, 70, 180, 36,
                           ART_BOX_HEIGHT, ART_BOX_WIDTH, ART_BOX_COLOUR),
                ])
                UPPER_SPACING = 10
                SPACING = 50
                DIMENSION = 40

                SAVE_BUTTON_COLOUR = (213, 43, 43)
                CLEAR_BUTTON_COLOUR = (160, 96, 96)
                QUIT_BUTTON_COLOUR = (181, 75, 75)
                LOAD_BUTTON_COLOUR = (202, 54, 54)

                save_button = SaveButton(SAVE_BUTTON_COLOUR, UPPER_SPACING, UPPER_SPACING, DIMENSION, DIMENSION, character="S")
                clear_button = ClearButton(CLEAR_BUTTON_COLOUR, UPPER_SPACING, UPPER_SPACING + SPACING, DIMENSION, DIMENSION, character="C")
                quit_button = Button(QUIT_BUTTON_COLOUR, UPPER_SPACING, UPPER_SPACING + SPACING * 2, DIMENSION, DIMENSION, character="Q")
                load_button = LoadButton(LOAD_BUTTON_COLOUR, UPPER_SPACING, UPPER_SPACING + SPACING * 3, DIMENSION, DIMENSION, character="L")

                display = pygame.display.set_mode((DISPLAY_WIDTH, DISPLAY_HEIGHT), pygame.RESIZABLE)

    pygame.display.update()
