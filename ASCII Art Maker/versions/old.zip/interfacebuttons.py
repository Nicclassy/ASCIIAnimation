import json

from typing import Tuple

from constants import *
from button import Button
from boxes import Boxes, ArtBox, CharacterBox


def name_save_file(extension: str):
    filename = SAVE_FILE_NAME
    count = 0
    while filename + "." + extension in os.listdir(SAVED_FILES_DIRECTORY):
        if count != 0:
            filename = filename[:-1]
        count += 1
        filename += str(count)
    return filename + "." + extension


def load_json_file(filename: str) -> Tuple[list, list]:
    art_box_json_data, character_box_json_data = open(os.path.join(SAVED_FILES_DIRECTORY, filename)).read().split("\n")
    return json.loads(art_box_json_data), json.loads(character_box_json_data)


def format_character_list(character_list: list, add_newlines: bool = False) -> str:
    list_string = ""
    for row in character_list:
        list_string += "".join(char if char else NO_DATA for char in row) + "\n" * add_newlines
    return list_string


class SaveButton(Button):

    def __init__(self, colour: tuple, left: int, top: int, width: int, height: int, character: str = "",
                 font_size: int = 25):
        super().__init__(colour, left, top, width, height, character, font_size)

    @staticmethod
    def export(boxes: Boxes, json_file: bool = False, art_only: bool = False):
        if json_file:
            file = open(os.path.join(SAVED_FILES_DIRECTORY, name_save_file("json")), "w")
            export_boxes = [boxes["art"]]
            if not art_only:
                export_boxes.append(boxes["character"])
            string_data = ""
            for box in export_boxes:
                string_data += json.dumps(box.character_list) + "\n"
            file.write(string_data.rstrip("\n"))
            file.close()
        else:
            ascii_art = format_character_list(boxes["art"].character_list)
            file = open(os.path.join(SAVED_FILES_DIRECTORY, name_save_file("txt")), "w")
            file.write(ascii_art)
            if not art_only:
                characters = format_character_list(boxes["character"].character_list)
                file.write(characters)
            file.close()


class ClearButton(Button):

    def __init__(self, colour: tuple, left: int, top: int, width: int, height: int, character: str = "",
                 font_size: int = 25):
        super().__init__(colour, left, top, width, height, character, font_size)

    @staticmethod
    def clear_data(art_box: ArtBox, character_box: CharacterBox):
        art_box.character_list = [[NO_DATA] * art_box.list_width for _ in range(art_box.list_height)]
        character_box.character_list = [[NO_DATA] * character_box.list_width for _ in range(character_box.list_height)]
        character_box.selected_position = (0, 0)
        character_box.coordinate_generator.position = 0


class LoadButton(Button):

    def __init__(self, colour: tuple, left: int, top: int, width: int, height: int, character: str = "",
                 font_size: int = 25):
        super().__init__(colour, left, top, width, height, character, font_size)

    @staticmethod
    def load_last_file(boxes: Boxes) -> str | None:
        number_index = len(SAVE_FILE_NAME) + 1
        file_number_groupings = [
            (filename[number_index], filename) for filename in os.listdir(SAVED_FILES_DIRECTORY)
            if filename.endswith("json")
        ]
        file_number_groupings.sort(reverse=True)
        if last_created_file := file_number_groupings[:1]:
            chosen_filename = last_created_file[0][1]
            art_box_data, character_box_data = load_json_file(chosen_filename)
            boxes["character"].character_list = character_box_data
            boxes["art"].character_list = art_box_data
            return chosen_filename


UPPER_SPACING = 10
SPACING = 50
DIMENSION = 40

SAVE_BUTTON_COLOUR = (213, 43, 43)
CLEAR_BUTTON_COLOUR = (160, 96, 96)
QUIT_BUTTON_COLOUR = (181, 75, 75)
LOAD_BUTTON_COLOUR = (202, 54, 54)

save_button = SaveButton(SAVE_BUTTON_COLOUR, UPPER_SPACING, UPPER_SPACING, DIMENSION, DIMENSION, character="S")
clear_button = ClearButton(CLEAR_BUTTON_COLOUR, UPPER_SPACING, UPPER_SPACING + SPACING, DIMENSION, DIMENSION, character="C")
quit_button = Button(QUIT_BUTTON_COLOUR, UPPER_SPACING, UPPER_SPACING + SPACING * 2, DIMENSION, DIMENSION, character="Q")
load_button = LoadButton(LOAD_BUTTON_COLOUR, UPPER_SPACING, UPPER_SPACING + SPACING * 3, DIMENSION, DIMENSION, character="L")
